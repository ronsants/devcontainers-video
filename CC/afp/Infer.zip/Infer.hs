-- compile with:
--    ghc --make -fglasgow-exts -o Infer.exe Infer

module Main where

import Control.Monad   (unless)
import Data.List       (union, delete, (\\))
import System.IO       (hFlush, stdout)
import UU_Scanner
import UU_Parsing_Core
import UU_Parsing_Derived 

------------------------------------------------------------
-- 1. Types and type schemes

infixr 5 :->:

data Scheme = Forall Int Scheme
            | Simple Type
   
data Type = TVar Int        -- type variable
          | TCon String     -- type constant
          | Type :->: Type  -- function type

bool, int :: Type
bool = TCon "Bool"
int  = TCon "Int"

instance Show Scheme where
   show = let f _ (Simple t)   = show t
              f c (Forall i s) = f (succ c) (singletonSubst i (TCon [c]) |-> s) 
          in f 'a'

instance Show Type where
   show (TVar i)     = "v" ++ show i
   show (TCon s)     = s
   show (t1 :->: t2) = 
      let isFunction (_ :->: _) = True
          isFunction _          = False
      in parIf (isFunction t1) (show t1) ++ " -> " ++ show t2 
 
parIf :: Bool -> String -> String
parIf b s = if b then "("++s++")" else s

------------------------------------------------------------
-- 2. Substitutions

infix 3 |->

type Substitution = Int -> Type

class Substitutable a where
   vars  :: a -> [Int]
   (|->) :: Substitution -> a -> a
   
instance Substitutable Type where
   vars (TVar i)     = [i]
   vars (t1 :->: t2) = vars t1 `union` vars t2
   vars _            = []
   
   sub |-> (TVar i)     = sub i
   sub |-> (t1 :->: t2) = (sub |-> t1) :->: (sub |-> t2)
   _   |-> t            = t

instance Substitutable Scheme where
   vars (Forall i s) = delete i (vars s)
   vars (Simple t)   = vars t
   
   sub |-> Forall i t = Forall i (removeFromSubst i sub |-> t)
   sub |-> Simple t   = Simple (sub |-> t)

instance Substitutable a => Substitutable [a] where
   vars = foldr (union . vars) []
   sub |-> as = map (sub |->) as

emptySubst :: Substitution
emptySubst = TVar

singletonSubst :: Int -> Type -> Substitution
singletonSubst i t = \j -> if i==j then t else TVar j

(@@) :: Substitution -> Substitution -> Substitution
s1 @@ s2 = (s1 |->) . s2

removeFromSubst :: Int -> Substitution -> Substitution
removeFromSubst i s = \j -> if i==j then TVar j else s j

------------------------------------------------------------
-- 3. A small expression language

data Expr = Var String            -- variable
          | Int Int               -- integer constant
          | Bool Bool             -- boolean constant
          | Apply Expr Expr       -- application
          | Lambda String Expr    -- lambda abstraction
          | Cond Expr Expr Expr   -- conditional
          | Let String Expr Expr  -- let expression

instance Show Expr where
   show (Var s)      = s
   show (Int i)      = show i
   show (Bool b)     = show b
   show (Apply f a)  = parIf (prioExpr f < 2) (show f) ++ " " ++ parIf (prioExpr a < 3) (show a)
   show (Lambda x e) = "\\" ++ x ++ " -> " ++ show e
   show (Cond b t e) = "if " ++ show b ++ " then " ++ show t ++ " else " ++ show e ++ " fi"
   show (Let x b d)  = "let " ++ x ++ " = " ++ show b ++ " in " ++ show d ++ " ni"

prioExpr :: Expr -> Int
prioExpr (Lambda _ _) = 1
prioExpr (Apply _ _)  = 2
prioExpr _            = 3

------------------------------------------------------------
-- 4. (Type) environments       
         
newtype Env a = Env [(String, a)]
type Gamma = Env Scheme

emptyEnv :: Env a
emptyEnv = Env []

extendEnv :: String -> a -> Env a -> Env a
extendEnv s t (Env xs) = Env ((s, t) : xs)

findInEnv :: String -> Env a -> Maybe a
findInEnv s (Env xs) = lookup s xs

instance Substitutable a => Substitutable (Env a) where
   vars (Env xs)  = vars (map snd xs)
   sub |-> env    = fmap (sub |->) env

instance Functor Env where
   fmap f (Env xs) = Env [ (s, f a) | (s, a) <- xs ]

------------------------------------------------------------
-- 5. Type inference utility functions

mgu :: Type -> Type -> Substitution
mgu (TVar i) t@(TVar j)
   | i == j    = emptySubst  
   | otherwise = singletonSubst i t
mgu (TVar i) t = varBind i t
mgu t (TVar i) = varBind i t
mgu (TCon s) (TCon t)
   | s == t    = emptySubst 
   | otherwise = error "#1: Type constants clash"
mgu (t1 :->: t2) (t3 :->: t4) = 
   let s = mgu t1 t3
   in mgu (s |-> t2) (s |-> t4) @@ s
mgu _ _ = error "#2: Type constant and function type clash"

varBind :: Int -> Type -> Substitution
varBind i t 
   | i `elem` vars t = error "#3: Occurs check failed" 
   | otherwise       = singletonSubst i t

generalize :: Substitutable a => a -> Type -> Scheme
generalize a t = foldr Forall (Simple t) (vars t \\ vars a)

instantiate :: Int -> Scheme -> (Int, Type)
instantiate n (Simple t)   = (n, t)
instantiate n (Forall i s) = 
   let (n', t) = instantiate n s 
   in (n'+1, singletonSubst i (TVar n') |-> t)

------------------------------------------------------------
-- 6. Type inference

infer :: Expr -> Scheme
infer expr = 
   let (scheme, _, _) = inferScheme 0 emptyEnv expr
   in scheme

inferScheme :: Int -> Gamma -> Expr -> (Scheme, Int, Substitution)
inferScheme i gamma expr = 
   let (t, i', s') = inferType i gamma expr
   in (generalize (s' |-> gamma) t, i', s')

inferType :: Int -> Gamma -> Expr -> (Type, Int, Substitution)
inferType i gamma expr = 
   case expr of
   
      Var s ->
         case findInEnv s gamma of
            Nothing -> error ("#4: Unbound variable " ++ show s)
            Just scheme -> 
               let (i', t) = instantiate i scheme
               in (t, i', emptySubst)
               
      Int _  -> 
         (int, i, emptySubst)
      
      Bool _ -> 
         (bool, i, emptySubst)
      
      Apply e1 e2 -> 
         let (t1, i1, s1) = inferType i gamma e1
             (t2, i2, s2) = inferType i1 (s1 |-> gamma) e2
             new = TVar i2
             s3 = mgu (s2 |-> t1) (t2 :->: new)
         in (s3 |-> new, i2+1, s3 @@ s2 @@ s1)
      
      Lambda x e -> 
         let new = TVar i
             (t1, i1, s1) = inferType (i+1) (extendEnv x (Simple new) gamma) e
         in ((s1 |-> new) :->: t1, i1, s1)
      
      Cond e1 e2 e3 ->
         let (t1, i1, s1) = inferType i  gamma e1
             (t2, i2, s2) = inferType i1 (s1 |-> gamma) e2
             (t3, i3, s3) = inferType i2 (s2 @@ s1 |-> gamma) e3
             s4 = mgu t1 bool
             s5 = mgu (s4 @@ s3 |-> t2) (s4 |-> t3)
         in (s5 @@ s4 |-> t3, i3, s5 @@ s4 @@ s3 @@ s2 @@ s1)
         
      Let x e1 e2 -> 
         let (scheme, i1, s1) = inferScheme i gamma e1
             (tp    , i2, s2) = inferType i1 (extendEnv x scheme gamma) e2
         in (tp, i2, s2 @@ s1)

------------------------------------------------------------
-- 7. Main functions

main :: IO ()
main = putStrLn (unlines signature) >> forever mainOnce

mainOnce :: IO ()
mainOnce = 
   do putStr "> "
      hFlush stdout -- flushes the command-prompt (only needed for putStr)
      input  <- getLine
      unless (null input) $
         do tokens <- hsScanner input
            case parse pExpr tokens of
               (expr, []) -> putStrLn (show expr ++ " :: " ++ show (infer expr))
               (_   , es) -> putStrLn "Syntax error:" >> 
                             putStrLn es

forever :: Monad m => m () -> m ()
forever m = m >> forever m

signature :: [String]
signature =
   [ "   _   ___ ___" 
   , "  /_\\ | __| _ \\        A Monadic Type Inferencer"
   , " / _ \\| _||  _/                (May 2005)"
   , "/_/ \\_\\_| |_|"
   ]
   
------------------------------------------------------------
-- 8. An expression scanner

keywordstxt, keywordsops :: [String]
specialchars, opchars :: [Char]
keywordstxt      = [ "if", "then", "else", "fi"
                   , "let",  "in", "ni"
                   , "True", "False"
                   , "Int", "Bool" 
                   ]
keywordsops      = [ "=", "\\", "->", "::", "@"]
specialchars     = "();,"
opchars          = "!#$%&*+/<=>?@\\^|-:."

hsScanner :: String -> IO [Token]
hsScanner = scanner False keywordstxt keywordsops specialchars opchars "(...)" . Just

------------------------------------------------------------
-- 9. An expression parser

pExpr, pApp, pFactor :: Parser Token Expr
pExpr   =  flip (foldr Lambda) 
           <$ pKey "\\"  <*> pList1 pVarid
           <* pKey "->"  <*> pExpr
       <|> pApp

pApp    = pChainl (pSucceed Apply) pFactor

pFactor =     pParens pExpr
          <|> (Int . read) <$> pInteger
          <|> Bool <$> (  True  <$ pKey "True"
                      <|> False <$ pKey "False"
                       )
          <|> Var <$> pVarid 
          <|> Cond <$ pKey "if"    <*> pExpr
                          <* pKey "then"  <*> pExpr
                          <* pKey "else"  <*> pExpr
                          <* pKey "fi"
          <|> Let <$ pKey "let" <*> pVarid <* pKey "=" <*> pExpr
                  <* pKey "in"  <*> pExpr
                  <* pKey "ni"