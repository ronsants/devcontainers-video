--  $Header: /data/cvs-rep/uust/lib/scanner/UU/Scanner/GenToken.hs,v 1.1 2002/11/13 16:05:20 uust Exp $
--  $Name:  $ (version name)

module UU.Scanner.GenToken where

import UU.Scanner.Position(Pos)

data GenToken key tp val =  Reserved !key !Pos
                         |  ValToken !tp val !Pos    
                 
position :: GenToken k t v -> Pos
position tok = case tok of
                   Reserved _ p   -> p
                   ValToken _ _ p -> p