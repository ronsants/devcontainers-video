--  $Header: /data/cvs-rep/uust/lib/scanner/UU/Scanner/GenTokenSymbol.hs,v 1.2 2003/04/16 10:37:09 uust Exp $
--  $Name:  $ (version name)

module UU.Scanner.GenTokenSymbol() where

import UU.Scanner.GenToken(GenToken(..))
import UU.Parsing.MachineInterface(Symbol(..))

instance Symbol (GenToken key tp val) where
  deleteCost (Reserved _ _) = 5
  deleteCost _              = 5
