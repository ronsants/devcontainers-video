--  $Header: /data/cvs-rep/uust/lib/pretty/UU/Pretty.hs,v 1.1 2002/11/13 16:05:20 uust Exp $
--  $Name:  $ (version name)

module UU.Pretty(module UU.Pretty.Basic, module UU.Pretty.Ext ) where

import UU.Pretty.Basic
import UU.Pretty.Ext